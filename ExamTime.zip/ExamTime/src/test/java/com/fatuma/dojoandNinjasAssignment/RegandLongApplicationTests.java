package com.fatuma.dojoandNinjasAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegandLongApplicationTests {

	@Test
	void contextLoads() {
	}

}
